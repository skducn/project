# coding=utf-8
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> >>
# Author     : John
# Created on : 2020-8-11
# Description: SAAS 之 注册管理
# *****************************************************************

from instance.zyjk.SAAS.PageObject.SaasPO import *
Saas_PO = SaasPO()
from PO.TimePO import *
time_PO = TimePO()
from PO.ListPO import *
List_PO = ListPO()
from PO.ColorPO import *
Color_PO = ColorPO()

# 1，登录 -  首页
Saas_PO.login("016", "123456")

Saas_PO.clickMenu("注册管理")
Saas_PO.clickMenu2("科室注册")



# # 2，新增
# Saas_PO.Web_PO.clickXpath("//button[@class='el-button right-add el-button--primary']", 2)  # 新增
# Saas_PO.Web_PO.inputXpath("//input[@placeholder='请输入医院名称']", "中国保健医院")  # 医院名称
# Saas_PO.Web_PO.inputXpath("//input[@placeholder='请输入医院代码']", "123456")  # 代码
# Saas_PO.Web_PO.inputXpath("//input[@placeholder='请输入医院负责人姓名']", "令狐冲")  # 负责人
# Saas_PO.Web_PO.clickXpath("//input[@placeholder='请输入所属地区']", 2)  # 所属地区
# list2 = Saas_PO.Web_PO.getXpathsText("//li")
# print(list2)

# Saas_PO.Web_PO.clickXpath("//a[@href='/admin/registrationManagement/medicalStaffRegistration']", 2)
# Saas_PO.Web_PO.clickXpath("//button[@class='el-button right-add el-button--primary']", 2)  # 新增
# Saas_PO.Web_PO.inputXpathEnter("//input[@placeholder='选择日期']", "2020-08-12")
# Saas_PO.Web_PO.inputXpathEnter('//*[@id="app"]/section/div/section/section/main/div/div/div[1]/div/div[2]/form/div[1]/div[2]/div[6]/div/div/input',"2020-08-13")
# Saas_PO.Web_PO.inputXpath("//input[@placeholder='请输入手机号码']", "13816109050")


# 3，搜索


