# coding=utf-8
# *****************************************************************
# Author     : John
# Date       : 2020-5-12
# Description: SAAS库
# *****************************************************************

import instance.zyjk.SAAS.config.readConfig as readConfig
localReadConfig = readConfig.ReadConfig()
from PO.LogPO import *
from PO.NetPO import *
from PO.DataPO import *
from PO.ColorPO import *
from PO.ExcelPO.ExcelPO import *
from PO.TimePO import *
from PO.SqlserverPO import *
from PO.FilePO import *
from PO.WebPO import *
from PO.ListPO import *
from PO.ColorPO import *
from time import sleep
from multiprocessing import Process

class SaasPO(object):

    def __init__(self):
        global ruleType,isRun,caseFrom,caseTo,curl,rulesApi,archiveNum,jar,excel,excelSheet1

        self.excelFile = localReadConfig.get_excel("excelFile")
        self.excelFileSheetName = localReadConfig.get_excel("excelFileSheetName")
        host = localReadConfig.get_database("host")
        username = localReadConfig.get_database("username")
        password = localReadConfig.get_database("password")
        database = localReadConfig.get_database("database")

        self.Sqlserver_PO = SqlServerPO(host, username, password, database)
        # logFile = localReadConfig.get_log("logFile")
        self.Time_PO = TimePO()
        self.File_PO = FilePO()
        self.Excel_PO = ExcelPO()
        # self.Log_PO = LogPO(logFile, fmt='%(levelname)s - %(message)s - %(asctime)s')  # 输出日志

        self.Web_PO = WebPO("chrome")
        self.Web_PO.openURL(localReadConfig.get_http("varUrl"))
        self.Web_PO.driver.maximize_window()  # 全屏
        # self.Web_PO.driver.set_window_size(1366,768)  # 按分辨率1366*768打开
        self.List_PO = ListPO()
        self.Color_PO = ColorPO()


    def login(self, varUser, varPass):

        ''' 登录 '''

        global varUser_session
        varUser_session = varUser

        self.Web_PO.inputXpath("//input[@placeholder='用户名']", varUser)
        self.Web_PO.inputXpath("//input[@placeholder='密码']", varPass)
        self.Web_PO.clickXpath("//button[@type='button']", 2)

    def clickMenu(self, varName):

        ''' 点击菜单1 '''

        list1 = self.Web_PO.getXpathsAttr("//li", "index")
        list1 = self.List_PO.listDel(list1, None)
        list2 = self.Web_PO.getXpathsText("//li")
        list2 = self.List_PO.listDel(list2, "")
        dict1 = self.List_PO.lists2dict(list2, list1)
        for k in dict1:
            if k == varName:
                self.Web_PO.clickXpath("//li[@index='" + dict1[k] + "']", 2)
                break
        sleep(3)

    def clickMenu2(self, varName):

        ''' 点击菜单2 '''

        list1 = self.Web_PO.getXpathsText("//a/li")
        list2 = self.Web_PO.getXpathsAttr("//a", "href")
        dict1 = self.List_PO.lists2dict(list1, list2)
        for k in dict1:
            if k == varName:
                x = str(dict1[k]).split("http://192.168.0.213")[1]
                self.Web_PO.clickXpath("//a[@href='" + x + "']", 2)
                break



if __name__ == '__main__':
    currentPath = os.path.split(os.path.realpath(__file__))[0]
    getConfig = os.path.join(currentPath, "config.ini")
    print(currentPath)
    # Saas_PO = SaasPO()


