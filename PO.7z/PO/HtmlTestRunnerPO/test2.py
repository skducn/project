# coding: utf-8
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# Author     : John
# Date       : 2018/4/20 15:04
# Description: HTMLTestRunner 对象层 之 运行脚本
# http://tungwaiyip.info/software/HTMLTestRunner.html
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


from PO.TimePO import *
time_PO = TimePO()

class Test2():

    def __init__(self, varFolder, varPattern, varReportFolder, varReport, varTitle, varDesc):
        # 类的构造函数
        print("2222222")

if __name__ == '__main__':
    pass