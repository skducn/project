# -*- coding: utf-8 -*-
# *********************************************************************
# Author        : John
# Date          : 2019-9-26
# Description   : excel 对象层
# http://www.cnblogs.com/snow-backup/p/4021554.html
# python处理Excel，pythonexcel http://www.bkjia.com/Pythonjc/926154.html
# python中处理excel表格，常用的库有xlrd（读）、xlwt（写）、openpyxl（读写）等。
# openpyxl xlsxwriter xlrd xlwt xlutils 这些库都没有提供修改 excel 表格内容功能，一般只能将原excel中的内容读出、做完处理后，再写入一个新的excel文件。

# 关于读表速度
# 1，读数据，xlrd 比 openpyxl 块很多，建议使用 xlrd 读取数，openpyxl写数据。
# 分析：xlrd 类似与数组一样，要取第几个元素，直接下标找到内存中对应地址的元素。
# openpyxl 根据行号列号读取的时候，是从第一行第一列开始遍历，直到行号等于指定行号，列号等于指定列号，所以要读取的行号列号越多就越慢（也可能是从第一个有数据的行或列）。
# 2，写数据，xlwt仅支持2003及以下版本，最大行数限制在65536，不够用，而openpyxl（excel2007）大概在一百多万。

# 问题1：处理 excel 表格时遇到的 unicode编码。
# python默认字符编码为unicode，所以从excel中读取的中文sheet或中文名时，会提示“UnicodeEncodeError: 'ascii' codec can't encode characters in position 0-2: ordinal not in range(128)。”
# 这是由于 windows里中文使用了gb2312编码方式，python误将其当作 unicode 和 ascii 来解码所造成的错误，使用“.encode('gb2312')”即可解决打印中文的问题。
# 可在文件名前加‘u’表示将该中文文件名采用unicode编码。

# 问题2：处理excel表格时遇到 excel中 时间显示错误。
# 有excel中，时间和日期都使用浮点数表示。如单元格中时间是 ‘2013年3月20日’，python输出为‘41353.0’；当其单元格格式改变为日期后，内容又变为了‘2013年3月20日’。
# 而使用xlrd读出excel中的日期和时间后，得到是的一个浮点数。所以当向excel中写入的日期和时间为一个浮点数也不要紧，只需将表格的表示方式改为日期和时间，即可得到正常的表示方式。
# excel中，用浮点数1表示1899年12月31日。
# python读取excel中单元格的内容返回的有5种类型，即上面例子中的ctype:
# ctype： 0 empty,1 string, 2 number, 3 date, 4 boolean, 5 error
# 如 sh.cell(2, 1).ctype == 3  判断某一单元格内容是否是日期
# *********************************************************************

from datetime import date
from time import sleep
import xlrd,xlwt
from xlutils.copy import copy
from openpyxl  import load_workbook
# import pandas as pd
# https://www.cnblogs.com/liulinghua90/p/9935642.html

class ExcelPO():

    def __init__(self):
        pass

    # 获取工作表名列表，如 ['Sheet1', 'Sheet2', 'Sheet3']
    def getAllSheetName(self, varFileName):
        try:
            wb = xlrd.open_workbook(filename=varFileName)
            return wb.sheet_names()
        except:
            exit()

    # 获取单个工作表名
    def getSheetNameByIndex(self, varFileName, varIndex):
        # 通过index方式获取 excel的工作表名，以字符串形式返回，如 'Sheet1'
        try:
            wb = xlrd.open_workbook(filename=varFileName)
            return wb.sheet_by_index(varIndex).name
        except:
            exit()

    # 获取总行数
    def getAllRows(self, varFileName, varSheet=0):
        # 获取总行数,默认varSheet是第一个Sheet1
        # print(Excel_PO.getAllRows("excel1.xls"))  # 10  //默认第一个Sheet1
        # print(Excel_PO.getAllRows("excel1.xls", 1))  # 12  //Sheet2
        # print(Excel_PO.getAllRows("excel1.xls", "Sheet3"))  # 10  //默认第一个sheet
        # print(Excel_PO.getAllRows("excel1.xls", "12Sheet3"))  # //不存在的表名，无返回值直接退出。
        try:
            wb = xlrd.open_workbook(filename=varFileName)
            if isinstance(varSheet, int):
                # sh = (wb.sheets()[varSheet])
                sh = wb.sheet_by_index(varSheet)
                return sh.nrows
            elif isinstance(varSheet, str):
                sh = wb.sheet_by_name(varSheet)
                return sh.nrows
            else:
                exit()
        except:
            exit()

    # 获取总行列数
    def getRowCol(self, varFileName, varSheet=0):
        # 获取行数和列数，以列表形式返回，如 [4,3]，表示 4行3列。可通过index或name方式定位工作表名
        list1 = []
        try:
            wb = xlrd.open_workbook(varFileName)
            if isinstance(varSheet, int):  # 判断变量的类型，int list tuple dict str 参考 https://www.cnblogs.com/fmgao-technology/p/9065753.html
                sh = wb.sheet_by_index(varSheet)
            else:
                sh = wb.sheet_by_name(varSheet)
            if wb.sheet_loaded(varSheet) == True:  # 检查 sheet是否导入完毕，返回True 或 False
                cols = sh.ncols
                rows = sh.nrows
                list1.append(rows)
                list1.append(cols)
            return list1
        except:
            exit()

    # 获取行值
    def getRowValue(self, varFileName, varRow, varSheet=0):
        # 获取行值，以列表形式返回，如 ['小寒1', '女', 58665985.0, datetime.date(2013, 3, 20), 134.0] , 异常返回 None，默认sheetNO=0定位第一个工作簿。
        # 对日期时间进行了处理，可正常返回 2013-03-20
        # 可使用切片获取某行某个单元值
        # 判断变量的类型isinstance，int list tuple dict str 参考 https://www.cnblogs.com/fmgao-technology/p/9065753.html
        # print(Excel_PO.getRowValue("excel1.xls", 0))  # ['id', 'name', 'age', 'date']  //获取Sheet1的第1行数据
        # print(Excel_PO.getRowValue("excel1.xls", 1, 0))  # ['1', 'yoyo', 30.0, datetime.date(2020, 3, 25)]  //获取Sheet1第2行数据，注意整数变成浮点数30.0，日期变成了43915.0
        # print(Excel_PO.getRowValue("excel1.xls", 2, "Sheet1"))  # ['2', 'jinhao', 35.0, datetime.date(2020, 4, 8)]  //获取Sheet1的第3行数据，注意日期变成了datetime.date()
        # print(Excel_PO.getColValue("excel1.xls", 0, "Sheet1"))  # ['id', '1', '2', '3', '4', '5', '6', '7', '8', '9'] // 获取Sheet1的第1列数据
        # print(Excel_PO.getColValue("excel1.xls", 5, 1))  # ['ab', 'yyo', 'aaa', 'yyo', 'yyo', 'yyo', 'yyo', 'yyo', 'yyo', 'yyo', 'yyo', 1212.0] //获取Sheet2的第6列数据
        # print(Excel_PO.getRowValue("excel1.xls", 1)[3])  # 2020-03-25  //获取Sheet1的第2行第4列
        # print(Excel_PO.getRowValue("excel1.xls", 0)[3])  # date

        list1 = []
        try:
            wb = xlrd.open_workbook(varFileName)
            if isinstance(varSheet, int):
                sh = wb.sheet_by_index(varSheet)
            else:
                sh = wb.sheet_by_name(varSheet)
            cols = sh.ncols
            for r in range(cols):
                if sh.cell(varRow , r).ctype == 3:
                    # value = xldate_as_datetime(sh.cell_value(rowx=varRow, colx=r), 0)
                    value = xlrd.xldate_as_tuple(sh.cell_value(rowx=varRow, colx=r), wb.datemode)
                    value = date(*value[:3])
                else:
                    value = sh.cell_value(rowx=varRow, colx=r)
                list1.append(value)
            return list1
        except:
            exit()

    # 获取列值
    def getColValue(self, varFileName, varCol, varSheet=0):
        # 获取某一列的值
        list1 = []
        try:
            wb = xlrd.open_workbook(varFileName)
            if isinstance(varSheet,int):
                sh = wb.sheet_by_index(varSheet)
            else:
                sh = wb.sheet_by_name(varSheet)
            rows = sh.nrows
            for r in range(rows):
                if sh.cell(r, varCol).ctype == 3:
                    value = xlrd.xldate_as_tuple(sh.cell_value(rowx=r, colx=varCol), wb.datemode)
                    value = date(*value[:3])
                else:
                    value = sh.cell_value(r, varCol)
                list1.append(value)
            return list1
        except:
            exit()

    # 设置表格样式
    def set_style(self, name, height, bold=False):
        style = xlwt.XFStyle()
        font = xlwt.Font()
        font.name = name
        font.bold = bold
        font.color_index = 4
        font.height = height
        style.font = font
        return style

    # 对 xls 写操作
    def writeXls(self, varFileName, varRow, varCol, varContent, varStyle, varSheet=0):
        # 写表操作，对单元格进行单个及批量写入（只支持.xls）
        # 注意：保留第一行第一列数据
        # Excel_PO.writeXls("excel1.xls", 2, 2, 77)  # 对Sheet1的第3行第3列 写入77
        # Excel_PO.writeXls("excel1.xls", "*", 5, "", "Sheet2")  # 对Sheet2的第6列写入空白（清除） (保留第一行，一般第一行是标题)
        # Excel_PO.writeXls("excel1.xls", 2, '*', 'ccc', 1)  # 对Sheet2的第3行写入aaa (保留第一列，一般第一列是标题)
        try:
            if varStyle == "blue":
                myStyle = xlwt.easyxf(u'font: height 260 ,name Times New Roman, color-index blue')
            elif varStyle == "red":
                myStyle = xlwt.easyxf(u'font: height 260 ,name Times New Roman, color-index red')
            else:
                myStyle = xlwt.easyxf(u'font: height 260 ,name Times New Roman, color-index black')
            wb = xlrd.open_workbook(filename=varFileName)
            if isinstance(varSheet, int):
                sh = wb.sheet_by_index(varSheet)
            elif isinstance(varSheet, str):
                sh = wb.sheet_by_name(varSheet)
            else:
                exit()
            wbk = copy(wb)
            sheet = wbk.get_sheet(varSheet)
            if varRow == "*":
                for i in range(sh.nrows):
                    sheet.write(i+1, varCol, varContent, myStyle)
            elif varCol == '*':
                for i in range(sh.ncols):
                    sheet.write(varRow, i+1, varContent, myStyle)
            else:
                sheet.write(varRow, varCol, varContent, myStyle)
            wbk.save(varFileName)
        except:
            exit()

    # 对 xlsx 写操作
    def writeXlsx(self, varFileName, varRow, varCol, varContent,varSheet=0):
        # 写表操作，对单元格进行写操作（只支持.xlsx）
        # Excel_PO.writeXlsx("excel3.xlsx", 5, 3, "令狐冲1")  # 对Sheet1的第5行第3列写入内容
        # Excel_PO.writeXlsx("excel3.xlsx", 6, 4, "你2好", "Sheet1")  # 对Sheet1的第6行第4列写入内容
        # Excel_PO.writeXlsx("excel3.xlsx", 5, 3, "100", 1)  # 对Sheet2的第5行第3列写入内容
        try:
            wb = load_workbook(varFileName)
            xl_sheet_names = wb.get_sheet_names()  # 获取所有sheet页名字
            if isinstance(varSheet, int):
                sh = wb.get_sheet_by_name(xl_sheet_names[varSheet])
            elif isinstance(varSheet, str):
                sh = wb.get_sheet_by_name(varSheet)
            else:
                exit()

            sh.cell(row=varRow, column=varCol, value=varContent)
            wb.save(varFileName)
        except:
            exit()

    # 删除行列
    def delRowColForXlsx(self, varFileName, varType, varFrom, varTo, varSheet=0):
        # 功能删除多行或多列。（for xlsx）
        # Excel_PO.delRowColForXlsx("excel3.xlsx", "col", 1, 2)  # 从第1列开始，连续删除2列
        # Excel_PO.delRowColForXlsx("excel3.xlsx", "row", 2, 3)  # 从第2行开始，连续删除3行
        try:
            wb = load_workbook(varFileName)
            xl_sheet_names = wb.get_sheet_names()
            # print(xl_sheet_names)  # 打印所有sheet页名称
            # 判断 varSheet 是数字还是字符
            if isinstance(varSheet, int):  # 判断是int类型
                # 定位到相应sheet页,[0]为sheet页索引
                wk_sheet = wb.get_sheet_by_name(xl_sheet_names[varSheet])
            elif isinstance(varSheet, str):
                wk_sheet = wb.get_sheet_by_name(varSheet)
            else:
                exit()

            if varType == "row":
                wk_sheet.delete_rows(varFrom, varTo)  # 删除从第一行开始算的2行内容
            elif varType == "col":
                wk_sheet.delete_cols(varFrom, varTo)  # 删除从第一列开始算的2列内容
            wb.save(varFileName)
        except:
            exit()

    # 清空单元格 for xlsx
    def clearRowColForXlsx(self, varFileName, varType, varNums, varSheet=0):
        # 清空整行整列
        # Excel_PO.clearRowColForXlsx("excel3.xlsx", "col", 1)  # 清空 Sheet1 的第1列
        # Excel_PO.clearRowColForXlsx("excel3.xlsx", "row", 2, "Sheet2")  # 清空Sheet2的第2行。
        # openpyxl的慢是读取慢，可以选择xlrd代替
        # 不直接使用xlwt + xlrd是因为xlwt仅支持2003及以下版本，最大行数限制在65536，不够用，而openpyxl大概在一百多万
        try:
            wb = load_workbook(varFileName)
            xl_sheet_names = wb.sheetnames
            if isinstance(varSheet, int):
                wk_sheet = wb.get_sheet_by_name(xl_sheet_names[varSheet])
                # wk_sheet = wb[varSheet]
            elif isinstance(varSheet, str):
                wk_sheet = wb[varSheet]
            else:
                exit()

            if varType == "col":
                for i in range(wk_sheet.max_row):
                    wk_sheet.cell(row=i+1, column=varNums, value="")  # 清除第row行的第col列
            elif varType == "row":
                for i in range(wk_sheet.max_row):
                    wk_sheet.cell(row=varNums, column=i+1, value="")  # 清除第row行的第col列
            wb.save(varFileName)
        except:
            exit()

if __name__ == "__main__":
    Excel_PO = ExcelPO()
    # print(Excel_PO.getAllSheetName("excel31.xlsx"))  # ['Sheet1', 'Sheet2', 'Sheet3']

    # print(Excel_PO.getSheetNameByIndex("excel1.xls", 0))  # Sheet1
    # print(Excel_PO.getSheetNameByIndex("excel1.xls", 1))  # Sheet2

    # print(Excel_PO.getAllRows("excel1.xls"))  # 10  //默认第一个Sheet1
    # print(Excel_PO.getAllRows("excel1.xls", 1))  # 12  //Sheet2
    # print(Excel_PO.getAllRows("excel1.xls", "Sheet3"))  # 10  //默认第一个sheet
    # print(Excel_PO.getAllRows("excel1.xls", "12Sheet3"))  #  //不存在的表名，无返回值直接退出。

    # print(Excel_PO.getRowCol("excel1.xls", 0))  # [10, 4]  // Sheet1共有10行4列
    # print(Excel_PO.getRowCol("excel1.xls", "Sheet2"))  # [12, 12]  // Sheet2中工有12行12列

    # print(Excel_PO.getRowValue("excel1.xls", 0))  # ['id', 'name', 'age', 'date']  //获取Sheet1的第1行数据
    # print(Excel_PO.getRowValue("excel1.xls", 1, 0))  # ['1', 'yoyo', 30.0, datetime.date(2020, 3, 25)]  //获取Sheet1第2行数据，注意整数变成浮点数30.0，日期变成了43915.0
    # print(Excel_PO.getRowValue("excel1.xls", 2, "Sheet1"))  # ['2', 'jinhao', 35.0, datetime.date(2020, 4, 8)]  //获取Sheet1的第3行数据，注意日期变成了datetime.date()
    # print(Excel_PO.getRowValue("excel1.xls", 1)[3])  # 2020-03-25  //获取Sheet1的第2行第4列
    # print(Excel_PO.getRowValue("excel1.xls", 0)[3])  # date

    # print(Excel_PO.getColValue("excel1.xls", 0, "Sheet1"))  # ['id', '1', '2', '3', '4', '5', '6', '7', '8', '9'] // 获取Sheet1的第1列数据
    # print(Excel_PO.getColValue("excel1.xls", 5, 1))  # ['ab', 'yyo', 'aaa', 'yyo', 'yyo', 'yyo', 'yyo', 'yyo', 'yyo', 'yyo', 'yyo', 1212.0] //获取Sheet2的第6列数据

    # Excel_PO.writeXls("excel1.xls", 2, 2, 77, "red")  # 对Sheet1的第3行第3列 写入77
    # Excel_PO.writeXls("excel1.xls", 1, 2, 6666, "blue", 0)  # 对Sheet1的第2行第3列 写入77
    # Excel_PO.writeXls("excel1.xls", "*", 5, "", "Sheet2")  # 对Sheet2的第6列写入空白（清除） (保留第一行，一般第一行是标题)
    # Excel_PO.writeXls("excel1.xls", 2, '*', 'ccc', "blue", 1)  # 对Sheet2的第3行写入aaa (保留第一列，一般第一列是标题)

    # Excel_PO.writeXlsx("excel3.xlsx", 5, 3, "令狐冲1")  # 对Sheet1的第5行第3列写入内容
    # Excel_PO.writeXlsx("excel3.xlsx", 6, 4, "你2好", "Sheet1")  # 对Sheet1的第6行第4列写入内容
    # Excel_PO.writeXlsx("excel3.xlsx", 5, 3, "100", 1)  # 对Sheet2的第5行第3列写入内容

    # Excel_PO.delRowColForXlsx("excel3.xlsx", "col", 2, 1, "Sheet2")  # 删除Sheet2的从第2列开始一列。
    # Excel_PO.delRowColForXlsx("excel3.xlsx", "row", 2, 2)  # 删除Sheet2的第3行,第4行

    # Excel_PO.clearRowColForXlsx("excel3.xlsx", "col", 1)  # 清空 Sheet1 的第1列
    # Excel_PO.clearRowColForXlsx("excel3.xlsx", "row", 2, "Sheet2")  # 清空Sheet2的第2行。


